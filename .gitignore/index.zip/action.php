<?php 
$file = $_POST['link'];
  if (!empty($file)==true){
   print " <script language=javascript> alert('기존에 있었던 음악은 삭제됩니다.');</script>";
   system("rm -rf /var/www/html/*.mp3");
   system("youtube-dl --extract-audio --audio-format mp3 -o \"%(title)s.%(ext)s\" $file");
   print " <script language=javascript> alert('다운로드를 완료했습니다.');</script>";
   header('Refresh: 1; url=index.php');
  }
 else{
  print " <script language=javascript> alert('링크를 입력해주세요.'); history.go(-1); </script>";
 }
?>
