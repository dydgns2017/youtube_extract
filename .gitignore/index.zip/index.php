<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="theme.css">
</head>

<body>
	<div class="container">
		
		<header>
			<h1>Youtube mp3 extract</h1>
		</header>

		<article>
			<p>유튜브 영상에서 mp3 파일을 추출합니다. 아래에 링크를 입력해주세요.</p>
			<form action="action.php" method="post">
			<p>유튜브 링크 입력 : <input type="text" name="link" ></p>
			<input type="submit" class="btn success"/>
			</form>
			<br/>
			<?php
			$file = system("ls -alf | grep *.mp3  | tail -1");
			if(!empty($file)){
			print '<a href="' . $file . ' " download>- Download</a>';
			}
			else{
				echo "다운로드된 MP3 파일이 없습니다.";
			}
			?>
			<br/>
			<br/>
		</article>
		
		
		<footer>Copyright &copy; Yonghoon Jung</footer>

	</div>

</body>
</html>